import re
from time import time

def words_from_file(filename):
    pattern = re.compile('[A-Za-z]+')
    for line in open(filename):
        yield from pattern.findall(line)

def freq(textfile, k):
    frequencies = {}
    for word in words_from_file(textfile):
        frequencies[word] = frequencies.get(word, 0) + 1
    most_frequent = sorted(frequencies.items(), key=lambda item: item[1], reverse=True)
    for i, (word, frequency) in enumerate(most_frequent):
        if i==k:
            break
        yield word, frequency

print("Starting...")
start = time()
print('\n'.join('{}\t{}'.format(f,w) for w, f in freq("4300-0.txt", 15)))
end = time()
print(end - start)
print("End.")

print("Starting Indonesia")
start = time()
print('\n'.join('{}\t{}'.format(f,w) for w, f in freq("indonesia_022020_tweets_csv_hashed.csv", 15)))
end = time()
print(end-start)
print("End.")
