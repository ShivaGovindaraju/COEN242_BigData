import numpy as np
from collections import Counter
import heapq
import csv
import re
from time import time

import sys
maxInt = sys.maxsize

while True:
    try:
        csv.field_size_limit(maxInt)
        break
    except OverflowError:
        maxInt = int(maxInt / 10)

# A naive approach
def topKMostFrequentWords(words, k):
    wordcount = Counter(words)
    heap = [(-freq, word) for word, freq in wordcount.items()]
    heapq.heapify(heap)
    return [ word for _, word in heapq.nsmallest(k, heap)]

# Now for some more sophistication...
def parseFileForTopKWords(filename, k):
    seenwords = {}
    counter = 0
    bcnt = 0
    with open(filename) as csvfile:
        currentblock = []
        filetext = csv.reader(csvfile, delimiter=' ', quotechar='|')
        for line in filetext:
            currentblock = currentblock + line
            counter = counter + 1
            if counter >= (1024):
                #print("Current block: {}".format(bcnt))
                bcnt = bcnt + 1
                blockcount = Counter(currentblock)
                counter = 0
                currentblock.clear()
                for word, freq in blockcount.items():
                    if word in seenwords:
                        seenwords[word] = seenwords[word] + freq
                    else:
                        seenwords[word] = freq
                #print("End block")
            #if bcnt > 256:
            #    print("Too long for testing. Breaking...")
            #    break
    heap = [(-freq, word) for word, freq in seenwords.items()]
    heapq.heapify(heap)
    return [word for _, word in heapq.nsmallest(k, heap)]

def findFileLength(filename):
    count = 0
    thefile = open(filename, 'rb')
    while 1:
        buff = thefile.read(8192*1024)
        if not buff:
            break
        count = count + buff.count('\n')
    thefile.close()
    return count

if __name__ == "__main__":
    print("Shiva Govindaraju COEN 242 Assignment 1")

    #print("Basic test of rudimentary functionality")
    #data = "Lorum ipsum delorum quod est demonstradum I walk a lonely road the only road that I have ever known dont know where it goes but its only me and I walk alone ah ah ah ah Fee fi fo fum I smell the blood of an english man we the people of the united states of america give me liberty or death"
    #print(topKMostFrequentWords(data.split(), 15))

    print("Testing on Ulysses text")
    start = time()
    print(parseFileForTopKWords("4300-0.txt", 15))
    end = time()
    print("Total Time: {}".format(end - start))

    #print("Testing on 1GB Indonesia tweets csvfile")
    #print( parseFileForTopKWords("indonesia_022020_tweets_csv_hashed.csv", 15) )
